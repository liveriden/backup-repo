<!--  -->
<div align="center">
  <h1>
    <b>###&nbsp;Hi&nbsp;there&nbsp;:watermelon:</b><br />
  </h1>
  <h2>
    <b>i&nbsp;Novice&nbsp;Developer&amp;a&nbsp;fan&nbsp;of&nbsp;funny&nbsp;ai</b><br />
  </h2>
  <div align="center">
    <img src="https://github.com/liveriden/lidev/raw/main/media/img/smile-browser-image.png" style="width: 192px;" align="center" /><br />
    <div align="center">
      <h2>
        <b>
          <a href="https://discord.gg/dzM8UDE8Jk">Discord&nbsp;</a>|
          <a href="https://matrix.to/#/#Liveriden-channel:matrix.org">Matrix&nbsp;</a><br />
        </b>
      </h2>
    </div>
  </div>
</div>


<p align="center">
  <a href="https://strapi.io/#gh-light-mode-only">
    <img src="https://github.com/liveriden/lidev/raw/main/media/img/smile-browser-image.png" width="192px" alt="Strapi logo" />
  </a>
  <a href="https://strapi.io/#gh-dark-mode-only">
    <img src="https://github.com/liveriden/lidev/raw/main/media/img/light-smile-browser-image.png" width="192px" alt="Strapi logo" />
  </a>
</p>


<div align="center">
<picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://github.com/liveriden/lidev/raw/main/media/img/smile-browser-image.png">
  <source media="(prefers-color-scheme: light)" srcset="https://github.com/liveriden/lidev/raw/main/media/img/smile-browser-image.png">
  <img alt="Shows an illustrated sun in light mode and a moon with stars in dark mode." src="https://github.com/liveriden/lidev/raw/main/media/img/smile-browser-image.png" style="width: 128px;" align="center" >
</picture>
</div>




<!-- <picture>
  <source media="(prefers-color-scheme: dark)" srcset="https://user-images.githubusercontent.com/25423296/163456776-7f95b81a-f1ed-45f7-b7ab-8fa810d529fa.png">
  <source media="(prefers-color-scheme: light)" srcset="https://user-images.githubusercontent.com/25423296/163456779-a8556205-d0a5-45e2-ac17-42d089e3c3f8.png">
  <img alt="Shows an illustrated sun in light mode and a moon with stars in dark mode." src="https://user-images.githubusercontent.com/25423296/163456779-a8556205-d0a5-45e2-ac17-42d089e3c3f8.png">
</picture> -->






<!-- <div align="center">
  <h1><strong>### Hi there :watermelon:<br></strong></h1>
  <h2><strong>i Novice Developer & a fan of funny ai<br></strong></h2>
  <div align="center" style="margin: 30px;">
  <img src="https://github.com/liveriden/lidev/raw/main/media/img/smile-browser-image.png"   style="width:128px;" />
  
  <div align="center">
    <h2>
      <strong>
      <a href="https://discord.gg/dzM8UDE8Jk">Discord</a> |
      <a href="https://matrix.to/#/#Liveriden-channel:matrix.org">Matrix</a>
    </strong>
    </h2>
  </div>
</div>
</div> -->














  

<!---
- 👋 Hi, I’m @liveriden
- 👀 I’m interested in ...
- 🌱 I’m currently learning ...
- 💞️ I’m looking to collaborate on ...
- 📫 How to reach me ...


liveriden/liveriden is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
