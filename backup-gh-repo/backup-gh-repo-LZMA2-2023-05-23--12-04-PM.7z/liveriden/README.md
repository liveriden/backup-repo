<div align="center">
  <h1>
    <b>###&nbsp;Hi&nbsp;there&nbsp;:watermelon:</b><br />
  </h1>
  <h2>
    <b>i&nbsp;Novice&nbsp;Developer&amp;a&nbsp;fan&nbsp;of&nbsp;funny&nbsp;ai</b><br />
  </h2>
  <div align="center">
    <img src="https://github.com/liveriden/lidev/raw/main/media/img/smile-browser-image.png" style="width: 320px;" align="center" /><br />
    <div align="center">
      <h2>
        <b>
          <a href="https://discord.gg/dzM8UDE8Jk">Discord&nbsp;</a>|
          <a href="https://matrix.to/#/#Liveriden-channel:matrix.org">Matrix&nbsp;</a><br />
        </b>
      </h2>
    </div>
  </div>
</div>

<!--
.

.

.

.

.
-->
<!-- <div align="center">
  <h1><strong>### Hi there :watermelon:<br></strong></h1>
  <h2><strong>i Novice Developer & a fan of funny ai<br></strong></h2>
  <div align="center" style="margin: 30px;">
  <img src="https://github.com/liveriden/lidev/raw/main/media/img/smile-browser-image.png"   style="width:128px;" />
  
  <div align="center">
    <h2>
      <strong>
      <a href="https://discord.gg/dzM8UDE8Jk">Discord</a> |
      <a href="https://matrix.to/#/#Liveriden-channel:matrix.org">Matrix</a>
    </strong>
    </h2>
  </div>
</div>
</div> -->
<!-- 
.

.

.

.

.
 -->
<!---
- 👋 Hi, I’m @liveriden
- 👀 I’m interested in ...
- 🌱 I’m currently learning ...
- 💞️ I’m looking to collaborate on ...
- 📫 How to reach me ...


liveriden/liveriden is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
<!-- 
.

.

.

.

.
 -->
<!-- 'liveridenʳ࿕☦' -->
