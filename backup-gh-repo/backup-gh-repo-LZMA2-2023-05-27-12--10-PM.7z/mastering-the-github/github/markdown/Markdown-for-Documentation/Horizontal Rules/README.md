# Horizontal Rules in MD files
```
Use one of the following in threes:

1. *
2. -
3. _

Note: If used after a one line paragraph, --- gives a heading.
```
Hello
***
Hello
---
---
Hello
___
