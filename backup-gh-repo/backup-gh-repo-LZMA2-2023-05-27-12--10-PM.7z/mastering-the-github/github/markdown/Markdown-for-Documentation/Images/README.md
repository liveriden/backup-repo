# Images using MD
```
To add images, following syntax is used:

![Alt title](Image link)
```
![GGs only](https://themaclife.com/wp-content/uploads/2016/12/cmpunk.jpg)

# Image with title
```
![Alt title](Image link "Title")
```
![GGs only](https://themaclife.com/wp-content/uploads/2016/12/cmpunk.jpg "Beautiful Image")

# Image with link
```
[![Alt title](Image link "Title")](link url)
```
[![GGs only](https://themaclife.com/wp-content/uploads/2016/12/cmpunk.jpg "Beautiful Image")](https://www.github.com/NishkarshRaj)
