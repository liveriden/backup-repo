# Paragraphs using MD

```
For creating paragraphs, just give one or more line gap between two paragraphs.
Note, indentation is carried out by the browser so we need not specify it explicitly.
```

Paragraph 1 

Paragraph 2
No Line break that means we are still in paragraph 2.