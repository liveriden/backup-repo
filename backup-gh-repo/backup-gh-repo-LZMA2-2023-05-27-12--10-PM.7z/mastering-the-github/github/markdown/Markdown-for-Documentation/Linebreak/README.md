# Line breaks in MD

```
There are two ways to stylize generic paragraphs of MD that uses <p> of HTML

1) Use <pre> tag of HTML
2) Use <br> tags is spaces are irrelevant and only linebreaks matter

Here, we use <br> for linebreaks.
```

Hello <br>World