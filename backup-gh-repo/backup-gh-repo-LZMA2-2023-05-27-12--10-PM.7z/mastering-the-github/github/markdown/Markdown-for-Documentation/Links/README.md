# Links using MD
```
To create a link

[Link to render on page](URL of the link)

Example: [GitHub](https://www.github.com)
```
[GitHub](https://www.github.com)

# Adding title to links using MD
```
Titles are tooltip that show up as an alert when the mouse is hovered over link.

Syntax: [Link to render on page](URL of link "Title")
```
[GitHub](https://www.github.com "GitHub website")

# URL and Email as link
```
To create links for URL and Email, use <>
<Email Address>
<Links>
```
Email: <500060720@stu.upes.ac.in> <br>
Git: <https://www.github.com/NishkarshRaj>
