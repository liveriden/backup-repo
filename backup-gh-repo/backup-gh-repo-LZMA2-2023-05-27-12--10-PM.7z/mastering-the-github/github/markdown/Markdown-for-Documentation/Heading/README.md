# Heading using MarkDown

```
Headings are specified using #
# Heading 1
## Heading 2
### Heading 3
#### Heading 4
##### Heading 5
###### Heading 6
```
*Size decreases from heading 1 to heading 6.*

# Heading 1
## Heading 2
### Heading 3
#### Heading 4
##### Heading 5
###### Heading 6

```
Alternate Headings are Heading 1 and Heading 2 in alternate fashion
They are defined by adding arbitrary numbers of ---- or ==== after alternate headings

For heading 1: use ===
For heading 2: use ---
```

Heading 1
--------
Heading 2
--------
Heading 3
----------
Heading 4
==========
