# Escape characters in MD
![Image for escape characters](https://github.com/NishkarshRaj/Markdown-for-Documentation/blob/master/Escaping%20Characters/Escape.png)

\* Oh I thought a list would have started with discs :smiley:
