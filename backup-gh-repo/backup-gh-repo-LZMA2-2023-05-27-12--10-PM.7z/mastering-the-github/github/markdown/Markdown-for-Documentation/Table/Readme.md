# Creating Tables with Headings

### Syntax

```md
| Heading 1 | Heading 2 |
| :-: | :-: |
| r1c1 | r1c2 | 
```

### Output

| Heading 1 | Heading 2 |
| :-: | :-: |
| r1c1 | r1c2 | 
