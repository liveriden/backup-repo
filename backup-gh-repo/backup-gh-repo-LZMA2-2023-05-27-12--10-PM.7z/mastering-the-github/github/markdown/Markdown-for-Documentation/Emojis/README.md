# Emojis in MD
```
Emojies are added using :<image flag>:
Example: :smiley:
```
:smiley:

[Emojies reference](https://github.com/ikatyang/emoji-cheat-sheet/blob/master/README.md)