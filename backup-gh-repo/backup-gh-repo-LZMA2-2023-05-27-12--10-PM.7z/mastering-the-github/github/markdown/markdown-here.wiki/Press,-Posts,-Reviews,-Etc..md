This is a collection of reviews and (non-trivial) blog posts about *Markdown Here*. Mostly pretty positive so far!

(Okay, this is primarily a vanity page. I'm happy to see people enjoy the thing I made.)

Chrome store reviews: https://chrome.google.com/webstore/detail/markdown-here/elifhakcjgalahccnjkneoccemfahfoa/reviews

Mozilla reviews: https://addons.mozilla.org/en-US/firefox/addon/markdown-here/#reviews

[Markdown Email - A Holy Grail](http://drezha.me.uk/post/33018298509/markdown-email-a-holy-grail) [drezha.me.uk]

[Markdown in Gmail: can be used thanks to a browser extension "Markdown Here"](http://caseywatts.github.com/2012/12/17/markdown_in_gmail/) [caseywatts.github.com]

[“Gmail”や“Evernote”で“Markdown”記法を利用可能にする「Markdown Here」](http://www.forest.impress.co.jp/docs/review/20130124_584862.html) [forest.impress.co.jp; Japanese]

[Gmail/YahooメールでMarkdownを使ってメール作成「Markdown Here」](http://www.moongift.jp/2013/01/20130110/) [moongift.jp; Japanese]

[markdown-here, writing email in Markdown?](http://blog.yjl.im/2012/06/markdown-here-writing-email-in-markdown.html) [blog.yjl.im; is against MDH and complex email]

[瀏覽器外掛Markdown Here讓你輕鬆用Markdown語法寫Mail](http://jdev.tw/blog/2694/markdown-here-plugin-for-browsers) [jdev.tw; Chinese]

[Markdown Here: Writing HTML In Emails Is Now Much Easier](http://www.smashingmagazine.com/smashing-newsletter-issue-62/#a4) [smashingmagazine.com]

[Review: Write better-formatted messages with Markdown Here](http://www.pcworld.com/article/2037007/review-write-better-formatted-messages-with-markdown-here.html) [pcworld.com]

[Free Chrome extensions power up Gmail](http://www.pcworld.com/article/2037000/free-chrome-extensions-power-up-gmail.html) [pcworld.com]

[G+ Post by Trey Harris](https://plus.google.com/116222833568410151476/posts/ajHcbK5zCpA) [plus.google.com]

[Markdown Here: Use Markdown Text In Gmail & Have It Rendered](http://www.makeuseof.com/tag/markdown-here-type-markdown-text-in-gmail-have-it-rendered-chrome/) [makeuseof.com]

[Write emails in Markdown and render them with Markdown Here!](http://thechangelog.com/write-emails-in-markdown-and-render-them-with-markdown-here/) [thechangelog.com]

[Markdown Here Adds Markdown Support to Email and Web Forms](http://lifehacker.com/markdown-here-adds-markdown-support-to-email-and-web-fo-785865889) [lifehacker.com]

[The Best Plugins to Supercharge Thunderbird](http://lifehacker.com/the-best-plugins-to-supercharge-thunderbird-807352970) [lifehacker.com]

[Markdown Here, aggiungere il supporto markdown ad email e servizi online](http://www.geekissimo.com/2013/07/16/markdown-here-aggiungere-supporto-markdown-email-servizi-online/) [geekissimo.com; Italian]

[POLUBIŁEM MARKDOWN](http://antyweb.pl/polubilem-markdown/) [antyweb.pl; Polish]

[Email Tips I Thought Were Common Knowledge](http://beust.com/weblog/2013/08/06/email-tips/) [beust.com; also at http://java.dzone.com/articles/email-tips-i-thought-were]

[Top 47 Google Chrome Productivity Extensions by Rating](http://www.lifehack.org/articles/technology/top-47-google-chrome-productivity-extensions-rating.html) [lifehack.org; MDH is #14]

[Usa Markdown para formatear correos electrónicos con Markdown Here](http://www.genbeta.com/correo/usa-markdown-para-formatear-correos-electronicos-con-markdown-here) [genbeta.com; Spanish]

[How to Use Markdown in Email and Google Mail](http://www.planetofthepenguins.com/technology/how-to-use-markdown-in-email-and-google-mail) [planetofthepenguins.com]

[The Tools I Use: Markdown Here](http://randycoulman.com/blog/2013/08/20/markdown-here/) [randycoulman.com]

[Spicing up Your Emails with Markdown](http://www.sitepoint.com/spicing-up-your-emails-with-markdown/) [sitepoint.com]

[Evernote-Web – Markdown-Erweiterung](http://www.notieren.de/evernote-web-markdown-erweiterung/) [notieren.de; German]


## Shorter posts about Markdown Here

https://plus.google.com/106557483623231970995/posts/DgfHXQCnxP4 [Jesse Wilson]

http://martenveldthuis.com/journal/markdown-here

http://joshualay.net/blog/2012/05/markdown-here/

https://plus.google.com/115056011540871202403/posts/72ZfSShdtW3 [Kevin Purdy]

https://twitter.com/pragdave/status/339388390145409024 [Dave Thomas; not gonna lie, I was super happy when the co-author of The Pragmatic Programmer tweeted about MDH]

http://gridwriter.com/2013/05/28/markdown-here/