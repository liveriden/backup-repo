# test-repository
изучение корректировки смены имени путей в файлах репозитория и подобных конфликтов  
studying the correction of path name changes in repository files and similar conflicts
