<div align="center">
  <h1>
    <b>###&nbsp;Hi&nbsp;there&nbsp;:watermelon:</b><br />
  </h1>
  <h2>
    <b>i&nbsp;Novice&nbsp;Developer&amp;a&nbsp;fan&nbsp;of&nbsp;funny&nbsp;ai</b><br />
  </h2>
  <div align="center">
    <img src="https://github.com/liveriden/lidev/raw/main/media/img/smile-browser-image.png" style="width: 320px;" align="center" />
    <div align="center">
      <h2>
        <b>
          <a href="https://discord.gg/dzM8UDE8Jk">Discord&nbsp;</a>|
          <a href="https://matrix.to/#/#Liveriden-channel:matrix.org">Matrix&nbsp;</a><br />
        </b>
      </h2>
    </div>
  </div>
</div>
<div align="center">

![Metrics](https://metrics.lecoq.io/liveriden?template=classic&introduction=1&activity=1&notable=1&achievements=1&discussions=1&repositories=1&people=1&followup=1&habits=1&stars=1&lines=1&languages=1&isocalendar=1&gists=1&base=header%2C%20activity%2C%20community%2C%20repositories%2C%20metadata&base.indepth=false&base.hireable=false&base.skip=false&repositories.batch=100&repositories.forks=false&repositories.affiliations=owner&isocalendar=false&isocalendar.duration=half-year&languages=false&languages.limit=8&languages.threshold=0%25&languages.other=false&languages.colors=github&languages.sections=most-used&languages.indepth=false&languages.analysis.timeout=15&languages.analysis.timeout.repositories=7.5&languages.categories=markup%2C%20programming&languages.recent.categories=markup%2C%20programming&languages.recent.load=300&languages.recent.days=14&lines=false&lines.sections=base&lines.repositories.limit=4&lines.history.limit=1&stars=false&stars.limit=4&habits=false&habits.from=200&habits.days=14&habits.facts=true&habits.charts=false&habits.charts.type=classic&habits.trim=false&habits.languages.limit=8&habits.languages.threshold=0%25&followup=false&followup.sections=repositories&followup.indepth=true&followup.archived=true&people=false&people.limit=24&people.identicons=false&people.identicons.hide=false&people.size=28&people.types=followers%2C%20following&people.shuffle=false&repositories=false&repositories.pinned=0&repositories.starred=0&repositories.random=0&repositories.order=featured%2C%20pinned%2C%20starred%2C%20random&discussions=false&discussions.categories=true&discussions.categories.limit=0&achievements=false&achievements.threshold=C&achievements.secrets=true&achievements.display=detailed&achievements.limit=0&notable=false&notable.from=all&notable.repositories=true&notable.indepth=false&notable.types=commit&notable.self=false&activity=false&activity.limit=5&activity.load=300&activity.days=14&activity.visibility=all&activity.timestamps=false&activity.filter=all&gists=false&introduction=false&introduction.title=true&config.timezone=Atlantic%2FReykjavik)
</div>

<!--
.

.

.

.

.
-->

<!-- <div align="center">
  <h1><strong>### Hi there :watermelon:<br></strong></h1>
  <h2><strong>i Novice Developer & a fan of funny ai<br></strong></h2>
  <div align="center" style="margin: 30px;">
  <img src="https://github.com/liveriden/lidev/raw/main/media/img/smile-browser-image.png"   style="width:128px;" />
  
  <div align="center">
    <h2>
      <strong>
      <a href="https://discord.gg/dzM8UDE8Jk">Discord</a> |
      <a href="https://matrix.to/#/#Liveriden-channel:matrix.org">Matrix</a>
    </strong>
    </h2>
  </div>
</div>
</div> -->

<!-- 
.

.

.

.

.
 -->
 
<!--
- 👋 Hi, I’m @liveriden
- 👀 I’m interested in ...
- 🌱 I’m currently learning ...
- 💞️ I’m looking to collaborate on ...
- 📫 How to reach me ...


liveriden/liveriden is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
-->

<!-- 
.

.

.

.

.
-->

<div align="center">
 
![](http://github-profile-summary-cards.vercel.app/api/cards/profile-details?username=liveriden&theme=dracula)

[📊 Metrics](https://metrics.lecoq.io/) | [:octocat: Github](https://github.com/)
</div>

<!-- 'liveridenʳ࿕☦' -->
